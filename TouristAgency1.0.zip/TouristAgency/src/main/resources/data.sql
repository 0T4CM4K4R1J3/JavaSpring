INSERT INTO drzava (id, naziv) values (101, "Srbija");
INSERT INTO drzava (id, naziv) values (102, "Crna Gora");

INSERT INTO grad (id, drzava_id, naziv) values (103, 101, "Beograd");
INSERT INTO grad (id, drzava_id, naziv) values (104, 101, "Novi Sad");
INSERT INTO grad (id, drzava_id, naziv) values (105, 102, "Budva");

INSERT INTO destinacija (id, grad_id, naziv) values (106, 103, "Interkontinental");
INSERT INTO destinacija (id, grad_id, naziv) values (107, 104, "Hajat");

INSERT INTO smestaj_opis (id, destinacija_id, adresa, cena, internet, opis, plaza, slika, zvezdica) 
				values (108, 106, "Milentija Popovica 1", 4000, true, "Neki opis", 300, "Putanja slike", 5);
				
INSERT INTO termin (id, polazak, povratak) values (109, "2022-10-1", "2022-10-14");

INSERT INTO aranzman (id, smestaj_opis_id, termin_id, broj_kreveta) values (110, 108, 109,  2);

INSERT INTO user (id, email, name, password, role) values (111, "pera@email.com", "Pera", "1234sifra", 0);

INSERT INTO prevoz (id, naziv) values (112, "Autobus");

INSERT INTO rezervacija (id, user_id, aranzman_id, prevoz_id, broj_odraslih, broj_dece, cena) 
				values (113, 111, 110, 112, 2, 2, 12000);