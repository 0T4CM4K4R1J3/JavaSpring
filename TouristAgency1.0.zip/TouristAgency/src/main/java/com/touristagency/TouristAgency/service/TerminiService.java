package com.touristagency.TouristAgency.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.TerminDTO;
import com.touristagency.TouristAgency.model.Termin;
import com.touristagency.TouristAgency.repository.TerminiRepository;

@Service
public class TerminiService {

	@Autowired
	TerminiRepository terminRepository;
	
	public TerminDTO createTermin(TerminDTO terminDTO) {
		Termin termin = new Termin(terminDTO);
		terminRepository.save(termin);
		return new TerminDTO(termin);
	}

	public List<Termin> getAllTermin(){
		return terminRepository.findAll(); 
	}

	public Termin getTermin(Long id) {
		return terminRepository.getReferenceById(id);
	}

	public Termin updateTermin(TerminDTO terminDTO) {
		Termin termin = this.getTermin(terminDTO.getId());
		termin.setPolazak(terminDTO.getPolazak());
		termin.setPovratak(terminDTO.getPovratak());
		return terminRepository.save(termin);
	}

	public void deleteTermin(Long id) {
		terminRepository.deleteById(id);
	}
}
