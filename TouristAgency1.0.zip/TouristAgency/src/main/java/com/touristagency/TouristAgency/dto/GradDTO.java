package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Grad;

public class GradDTO {

	private Long id;
	private String naziv;
	private Long drzavaId;
	
	public GradDTO() {}
	
	public GradDTO(Grad grad) {
		this.id = grad.getId();
		this.naziv = grad.getNaziv();
		this.drzavaId = grad.getDrzava().getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Long getDrzavaId() {
		return drzavaId;
	}

	public void setDrzavaId(Long drzavaId) {
		this.drzavaId = drzavaId;
	}
	
	
}
