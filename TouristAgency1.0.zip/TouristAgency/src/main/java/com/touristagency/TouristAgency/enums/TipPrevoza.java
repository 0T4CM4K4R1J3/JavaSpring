package com.touristagency.TouristAgency.enums;

public enum TipPrevoza {
Sopstveni, Autobus, Avion
}
