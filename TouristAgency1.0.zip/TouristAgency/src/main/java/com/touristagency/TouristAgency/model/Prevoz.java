package com.touristagency.TouristAgency.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.touristagency.TouristAgency.dto.PrevozDTO;

@Entity
public class Prevoz {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	private String naziv;
	
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="prevoz")
	private List<Rezervacija> rezervacije = new ArrayList<>();
	
	
	public Prevoz() {}
	
	public Prevoz(PrevozDTO prevoz) {
		this.naziv = prevoz.getNaziv();
	}

	public Long getId() {
		return id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Rezervacija> getRezervacije() {
		return rezervacije;
	}

	public void setRezervacije(List<Rezervacija> rezervacije) {
		this.rezervacije = rezervacije;
	}
	
	
	
	
}
