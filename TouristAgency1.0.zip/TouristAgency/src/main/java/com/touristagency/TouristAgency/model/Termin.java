package com.touristagency.TouristAgency.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.touristagency.TouristAgency.dto.TerminDTO;

@Entity
public class Termin {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	private Date polazak;
	private Date povratak;
	
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="termin")
	private List<Aranzman> aranzmani = new ArrayList<>();
	
	public Termin() {}
	
	public Termin(TerminDTO a) {
		this.polazak = a.getPolazak();
		this.povratak = a.getPovratak();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getPolazak() {
		return polazak;
	}

	public void setPolazak(Date polazak) {
		this.polazak = polazak;
	}

	public Date getPovratak() {
		return povratak;
	}

	public void setPovratak(Date povratak) {
		this.povratak = povratak;
	}

	public List<Aranzman> getAranzmani() {
		return aranzmani;
	}

	public void setAranzmani(List<Aranzman> aranzmani) {
		this.aranzmani = aranzmani;
	}
	
	
	
}
