package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Destinacija;

public class DestinacijaDTO {

	private Long id;
	private String naziv;
	private Long gradId;
	
	public DestinacijaDTO() {}

	public DestinacijaDTO(Destinacija destinacija) {
		this.id = destinacija.getId();
		this.naziv = destinacija.getNaziv();
		this.gradId = destinacija.getGrad().getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Long getGradId() {
		return gradId;
	}

	public void setGradId(Long gradId) {
		this.gradId = gradId;
	}
	
	
}
