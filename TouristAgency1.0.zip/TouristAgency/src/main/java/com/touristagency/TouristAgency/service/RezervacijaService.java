package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.RezervacijaDTO;
import com.touristagency.TouristAgency.model.Rezervacija;
import com.touristagency.TouristAgency.repository.AranzmanRepository;
import com.touristagency.TouristAgency.repository.PrevozRepository;
import com.touristagency.TouristAgency.repository.RezervacijaRepository;
import com.touristagency.TouristAgency.repository.UserRepository;

@Service
public class RezervacijaService {

	@Autowired
	RezervacijaRepository rezervacijaRepository;
	@Autowired
	AranzmanService aranzmanService;
	@Autowired
	AranzmanRepository aranzmanRepository;
	@Autowired
	UserService userService;
	@Autowired
	UserRepository userRepository;
	@Autowired
	PrevozService prevozService;
	@Autowired
	PrevozRepository prevozRepository;
	
	public RezervacijaDTO createRezervacija(RezervacijaDTO rezervacijaDTO) {
		Rezervacija rezervacija = new Rezervacija(rezervacijaDTO);
		rezervacija.setAranzman(aranzmanRepository.getReferenceById(rezervacijaDTO.getAranzmanId()));
		rezervacija.setUser(userRepository.getReferenceById(rezervacijaDTO.getUserId()));
		rezervacija.setPrevoz(prevozRepository.getReferenceById(rezervacijaDTO.getPrevozId()));
		rezervacijaRepository.save(rezervacija);
		return new RezervacijaDTO(rezervacija);
	}
	
	public List<RezervacijaDTO> getAllRezervacija(){
		List<Rezervacija> rezervacije = rezervacijaRepository.findAll(); 
		List<RezervacijaDTO> rezervacijeDTO = new ArrayList<>();
		for(Rezervacija rezervacija : rezervacije) {
			rezervacijeDTO.add(new RezervacijaDTO(rezervacija));
		}
		return rezervacijeDTO; 
	}

	public RezervacijaDTO getRezervacija(Long id) {
		return new RezervacijaDTO(rezervacijaRepository.getReferenceById(id));
	}

	public RezervacijaDTO updateRezervacija(RezervacijaDTO rezervacijaDTO) {
		Rezervacija rezervacija = this.rezervacijaRepository.getReferenceById(rezervacijaDTO.getId());
		rezervacija.setUser(this.userRepository.getReferenceById(rezervacijaDTO.getUserId()));
		rezervacija.setPrevoz(this.prevozRepository.getReferenceById(rezervacijaDTO.getPrevozId()));
		rezervacija.setAranzman(this.aranzmanRepository.getReferenceById(rezervacijaDTO.getAranzmanId()));
		return new RezervacijaDTO(rezervacijaRepository.save(rezervacija));
	}

	public void deleteRezervacija(Long id) {
		rezervacijaRepository.deleteById(id);
	}
	
	
	
}
