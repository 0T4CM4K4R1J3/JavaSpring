package com.touristagency.TouristAgency.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.PrevozDTO;
import com.touristagency.TouristAgency.model.Prevoz;
import com.touristagency.TouristAgency.repository.PrevozRepository;

@Service
public class PrevozService {

	@Autowired
	PrevozRepository prevozRepository;
	
	public PrevozDTO createPrevoz(PrevozDTO prevozDTO) {
		Prevoz prevoz = new Prevoz(prevozDTO);
		prevozRepository.save(prevoz);
		return new PrevozDTO(prevoz);
	}

	public List<Prevoz> getAllPrevoz(){
		return prevozRepository.findAll(); 
	}

	public Prevoz getPrevoz(Long id) {
		return prevozRepository.getReferenceById(id);
	}

	public Prevoz updatePrevoz(PrevozDTO prevozDTO) {
		Prevoz prevoz = this.getPrevoz(prevozDTO.getId());
		prevoz.setNaziv(prevozDTO.getNaziv());
		return prevozRepository.save(prevoz);
	}

	public void deletePrevoz(Long id) {
		prevozRepository.deleteById(id);
	}
}
