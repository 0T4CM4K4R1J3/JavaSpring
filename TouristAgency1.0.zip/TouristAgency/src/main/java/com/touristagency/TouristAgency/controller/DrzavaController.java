package com.touristagency.TouristAgency.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.DrzavaDTO;
import com.touristagency.TouristAgency.model.Drzava;
import com.touristagency.TouristAgency.service.DrzavaService;

@RestController
@RequestMapping(value="drzava")
public class DrzavaController {

	@Autowired
	DrzavaService drzavaService;
	
	@PostMapping	
	public ResponseEntity<DrzavaDTO> createDrzava(@RequestBody DrzavaDTO drzavaDTO) {	
		DrzavaDTO drzava = drzavaService.createDrzava(drzavaDTO);		
		return new ResponseEntity<DrzavaDTO>(drzava, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Drzava>> getAllDrzava(){
		List<Drzava> drzave = drzavaService.getAllDrzava();
		return new ResponseEntity<List<Drzava>>(drzave, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<Drzava> getDrzava(@PathVariable Long id){
		Drzava drzava = drzavaService.getDrzava(id);
		return new ResponseEntity<Drzava>(drzava, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<Drzava> updateDrzava(@RequestBody DrzavaDTO drzavaDTO) {	
		Drzava drzava = drzavaService.updateDrzava(drzavaDTO);		
		return new ResponseEntity<Drzava>(drzava, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteDrzava(@PathVariable Long id){
		drzavaService.deleteDrzava(id);
		return new ResponseEntity<>("Drzava uspesno obrisana", HttpStatus.OK);
	}
}
