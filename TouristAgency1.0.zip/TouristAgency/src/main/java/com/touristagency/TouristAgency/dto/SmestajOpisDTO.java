package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.SmestajOpis;

public class SmestajOpisDTO {

	private Long id;	
	private String adresa;
	private String slika;	
	private int zvezdica;	
	private int plaza;	
	private boolean internet;	
	private String opis;	
	private int cena;
	private Long destinacijaId;
	
	public SmestajOpisDTO() {}

	public SmestajOpisDTO(SmestajOpis smestajOpis) {
		this.id = smestajOpis.getId();
		this.adresa = smestajOpis.getAdresa();
		this.slika = smestajOpis.getSlika();
		this.zvezdica = smestajOpis.getZvezdica();
		this.plaza = smestajOpis.getPlaza();
		this.internet = smestajOpis.isInternet();
		this.opis = smestajOpis.getOpis();
		this.cena = smestajOpis.getCena();
		this.destinacijaId = smestajOpis.getDestinacija().getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	public String getSlika() {
		return slika;
	}

	public void setSlika(String slika) {
		this.slika = slika;
	}

	public int getZvezdica() {
		return zvezdica;
	}

	public void setZvezdica(int zvezdica) {
		this.zvezdica = zvezdica;
	}

	public int getPlaza() {
		return plaza;
	}

	public void setPlaza(int plaza) {
		this.plaza = plaza;
	}

	public boolean isInternet() {
		return internet;
	}

	public void setInternet(boolean internet) {
		this.internet = internet;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public int getCena() {
		return cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}

	public Long getDestinacijaId() {
		return destinacijaId;
	}

	public void setDestinacijaId(Long destinacijaId) {
		this.destinacijaId = destinacijaId;
	}
	
	
	
}
