package com.touristagency.TouristAgency.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.touristagency.TouristAgency.dto.AranzmanDTO;

@Entity
public class Aranzman {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="aranzman")
	private List<Rezervacija> rezervacije = new ArrayList<>();
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	private Termin termin;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	private SmestajOpis smestajOpis;
	
	private int brojKreveta;
	
	public Aranzman() {}
	
	public Aranzman(AranzmanDTO a) {
		this.brojKreveta = a.getBrojKreveta();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Rezervacija> getRezervacije() {
		return rezervacije;
	}

	public void setRezervacije(List<Rezervacija> rezervacije) {
		this.rezervacije = rezervacije;
	}

	public Termin getTermin() {
		return termin;
	}

	public void setTermin(Termin termin) {
		this.termin = termin;
	}

	public SmestajOpis getSmestajOpis() {
		return smestajOpis;
	}

	public void setSmestajOpis(SmestajOpis smestajOpis) {
		this.smestajOpis = smestajOpis;
	}

	public int getBrojKreveta() {
		return brojKreveta;
	}

	public void setBrojKreveta(int brojKreveta) {
		this.brojKreveta = brojKreveta;
	}
	
}
