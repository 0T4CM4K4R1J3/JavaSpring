package com.touristagency.TouristAgency.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.touristagency.TouristAgency.model.SmestajOpis;

@Repository
public interface SmestajOpisRepository extends JpaRepository<SmestajOpis,Long>  {

}
