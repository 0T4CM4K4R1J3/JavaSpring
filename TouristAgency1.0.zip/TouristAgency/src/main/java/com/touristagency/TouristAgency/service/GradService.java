package com.touristagency.TouristAgency.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.touristagency.TouristAgency.dto.GradDTO;
import com.touristagency.TouristAgency.model.Grad;
import com.touristagency.TouristAgency.repository.GradRepository;

@Service
public class GradService {

	@Autowired
	GradRepository gradRepository;
	@Autowired
	DrzavaService drzavaService;
	
	public GradDTO createGrad(GradDTO gradDTO) {
		Grad grad = new Grad(gradDTO);
		grad.setDrzava(drzavaService.getDrzava(gradDTO.getDrzavaId()));
		gradRepository.save(grad);
		return new GradDTO(grad);
	}
	
	public List<GradDTO> getAllGrad(){
		List<Grad> gradovi = gradRepository.findAll(); 
		List<GradDTO> gradoviDTO = new ArrayList<>();
		for(Grad grad : gradovi) {
			gradoviDTO.add(new GradDTO(grad));
		}
		return gradoviDTO;
	}

	public GradDTO getGrad(Long id) {
		return new GradDTO(gradRepository.getReferenceById(id));
	}

	public GradDTO updateGrad(GradDTO gradDTO) {
		Grad grad = gradRepository.getReferenceById(gradDTO.getId());
		grad.setDrzava(drzavaService.getDrzava(gradDTO.getDrzavaId()));
		grad.setNaziv(gradDTO.getNaziv());
		return new GradDTO(gradRepository.save(grad));
	}

	public void deleteGrad(Long id) {
		gradRepository.deleteById(id);
	}
}
