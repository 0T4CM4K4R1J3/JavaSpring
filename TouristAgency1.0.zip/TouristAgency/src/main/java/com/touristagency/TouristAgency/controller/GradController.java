package com.touristagency.TouristAgency.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.GradDTO;
import com.touristagency.TouristAgency.service.GradService;

@RestController
@RequestMapping(value="grad")
public class GradController {

	@Autowired
	GradService gradService;
	
	@PostMapping	
	public ResponseEntity<GradDTO> createGrad(@RequestBody GradDTO gradDTO) {	
		GradDTO grad = gradService.createGrad(gradDTO);		
		return new ResponseEntity<GradDTO>(grad, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<GradDTO>> getAllGrad(){
		List<GradDTO> gradovi = gradService.getAllGrad();
		return new ResponseEntity<List<GradDTO>>(gradovi, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<GradDTO> getGrad(@PathVariable Long id){
		GradDTO grad = gradService.getGrad(id);
		return new ResponseEntity<GradDTO>(grad, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<GradDTO> updateGrad(@RequestBody GradDTO gradDTO) {	
		GradDTO grad = gradService.updateGrad(gradDTO);		
		return new ResponseEntity<GradDTO>(grad, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteGrad(@PathVariable Long id){
		gradService.deleteGrad(id);
		return new ResponseEntity<>("Grad uspesno obrisan", HttpStatus.OK);
	}
}
