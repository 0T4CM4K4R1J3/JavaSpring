package com.touristagency.TouristAgency.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.PrevozDTO;
import com.touristagency.TouristAgency.model.Prevoz;
import com.touristagency.TouristAgency.service.PrevozService;

@RestController
@RequestMapping(value="prevoz")
public class PrevozController {
	
	@Autowired
	PrevozService prevozService;

	@PostMapping	
	public ResponseEntity<PrevozDTO> createPrevoz(@RequestBody PrevozDTO prevozDTO) {	
		PrevozDTO prevoz = prevozService.createPrevoz(prevozDTO);		
		return new ResponseEntity<PrevozDTO>(prevoz, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Prevoz>> getAllPrevoz(){
		List<Prevoz> prevozi = prevozService.getAllPrevoz();
		return new ResponseEntity<List<Prevoz>>(prevozi, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<Prevoz> getPrevoz(@PathVariable Long id){
		Prevoz prevoz = prevozService.getPrevoz(id);
		return new ResponseEntity<Prevoz>(prevoz, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<Prevoz> updatePrevoz(@RequestBody PrevozDTO prevozDTO) {	
		Prevoz prevoz = prevozService.updatePrevoz(prevozDTO);		
		return new ResponseEntity<Prevoz>(prevoz, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deletePrevoz(@PathVariable Long id){
		prevozService.deletePrevoz(id);
		return new ResponseEntity<>("Prevoz uspesno obrisan", HttpStatus.OK);
	}
}
