package com.touristagency.TouristAgency.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.RezervacijaDTO;
import com.touristagency.TouristAgency.service.RezervacijaService;

@RestController
@RequestMapping(value="rezervacija")
public class RezervacijaController {

	@Autowired
	RezervacijaService rezervacijaService;
	
	@PostMapping	
	public ResponseEntity<RezervacijaDTO> createRezervacija(@RequestBody RezervacijaDTO rezervacijaDTO) {	
		RezervacijaDTO rezervacija = rezervacijaService.createRezervacija(rezervacijaDTO);		
		return new ResponseEntity<RezervacijaDTO>(rezervacija, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<RezervacijaDTO>> getAllRezervacije(){
		List<RezervacijaDTO> rezervacije = rezervacijaService.getAllRezervacija();
		return new ResponseEntity<List<RezervacijaDTO>>(rezervacije, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<RezervacijaDTO> getRezervacija(@PathVariable Long id){
		RezervacijaDTO rezervacija = rezervacijaService.getRezervacija(id);
		return new ResponseEntity<RezervacijaDTO>(rezervacija, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<RezervacijaDTO> updateRezervacija(@RequestBody RezervacijaDTO rezervacijaDTO) {	
		RezervacijaDTO rezervacija = rezervacijaService.updateRezervacija(rezervacijaDTO);		
		return new ResponseEntity<RezervacijaDTO>(rezervacija, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteRezervacija(@PathVariable Long id){
		rezervacijaService.deleteRezervacija(id);
		return new ResponseEntity<>("Rezervacija uspesno obrisana", HttpStatus.OK);
	}
}
