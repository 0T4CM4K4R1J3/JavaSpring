package com.touristagency.TouristAgency.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.touristagency.TouristAgency.dto.DestinacijaDTO;
import com.touristagency.TouristAgency.service.DestinacijaService;

@RestController
@RequestMapping(value="destinacija")
public class DestinacijaController {

	@Autowired
	DestinacijaService destinacijaService;
	
	@PostMapping	
	public ResponseEntity<DestinacijaDTO> createDestinacija(@RequestBody DestinacijaDTO destinacijaDTO) {	
		DestinacijaDTO destinacija = destinacijaService.createDestinacija(destinacijaDTO);		
		return new ResponseEntity<DestinacijaDTO>(destinacija, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<DestinacijaDTO>> getAllDestinacij(){
		List<DestinacijaDTO> destinacija = destinacijaService.getAllDestinacija();
		return new ResponseEntity<List<DestinacijaDTO>>(destinacija, HttpStatus.OK);
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<DestinacijaDTO> getDestinacija(@PathVariable Long id){
		DestinacijaDTO destinacija = destinacijaService.getDestinacija(id);
		return new ResponseEntity<DestinacijaDTO>(destinacija, HttpStatus.OK);
	}
	
	@PutMapping	
	public ResponseEntity<DestinacijaDTO> updateDestinacija(@RequestBody DestinacijaDTO destinacijaDTO) {	
		DestinacijaDTO destinacija = destinacijaService.updateDestinacija(destinacijaDTO);		
		return new ResponseEntity<DestinacijaDTO>(destinacija, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}")
	public ResponseEntity<?> deleteDestinacija(@PathVariable Long id){
		destinacijaService.deleteDestinacija(id);
		return new ResponseEntity<>("Destinacija uspesno obrisana", HttpStatus.OK);
	}
}
