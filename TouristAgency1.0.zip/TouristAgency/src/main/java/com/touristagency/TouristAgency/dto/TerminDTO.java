package com.touristagency.TouristAgency.dto;

import java.util.Date;

import com.touristagency.TouristAgency.model.Termin;

public class TerminDTO {

	private Long id;
	
	private Date polazak;
	
	private Date povratak;
	
	public TerminDTO() {}

	public TerminDTO(Termin termin) {
		this.id = termin.getId();
		this.polazak = termin.getPolazak();
		this.povratak = termin.getPovratak();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getPolazak() {
		return polazak;
	}

	public void setPolazak(Date polazak) {
		this.polazak = polazak;
	}

	public Date getPovratak() {
		return povratak;
	}

	public void setPovratak(Date povratak) {
		this.povratak = povratak;
	}
	
	
}
