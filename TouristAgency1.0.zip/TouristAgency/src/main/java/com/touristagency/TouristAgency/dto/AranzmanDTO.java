package com.touristagency.TouristAgency.dto;

import com.touristagency.TouristAgency.model.Aranzman;

public class AranzmanDTO {

	private Long id;
	private int brojKreveta;
	private Long smestajOpisId;
	private Long terminId;
	
	public AranzmanDTO() {}

	public AranzmanDTO(Aranzman aranzman) {
		this.id = aranzman.getId();
		this.brojKreveta = aranzman.getBrojKreveta();
		this.smestajOpisId = aranzman.getSmestajOpis().getId();
		this.terminId = aranzman.getTermin().getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getBrojKreveta() {
		return brojKreveta;
	}

	public void setBrojKreveta(int brojKreveta) {
		this.brojKreveta = brojKreveta;
	}

	public void setSmestajOpisId(Long smestajOpisId) {
		this.smestajOpisId = smestajOpisId;
	}

	public Long getSmestajOpisId() {
		return smestajOpisId;
	}

	public Long getTerminId() {
		return terminId;
	}

	public void setTerminId(Long terminId) {
		this.terminId = terminId;
	}
	
	
}
